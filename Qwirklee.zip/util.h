#ifndef UTIL_H
#define UTIL_H

int powInt(int b, int e);

int convCharToInt(char c);
int lerIntSTDIN(int *n);
int cmpStr(char *str1, char *str2);

#endif